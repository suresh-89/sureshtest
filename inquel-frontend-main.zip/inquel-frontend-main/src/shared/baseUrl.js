export const baseUrl = "https://api.iqlabsacademy.com/";

export const accountsUrl = "2d7a_3fde/api/v1/accounts";

export const adminPathUrl = "52fd_1f4a/api/v1/admin";

export const inquelAdminUrl = "22de_06a2/api/v1/inquel_admin";

export const hodUrl = "424f_0659/api/v1";

export const teacherUrl = "3a3c_a1a6/api/v1";

export const studentUrl = "5ddf_cae2/api/v1";

export const homeURL = "a69e_f43e/api/v1/website";
